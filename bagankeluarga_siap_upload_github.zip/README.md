# Bagan Keluarga Jepang

## File website
- `index.html`: struktur halaman.
- `style.css`: desain dan warna.
- `script.js`: tombol masuk dan kembali.

## Foto yang perlu diletakkan di folder yang sama dengan index.html
Pastikan nama file foto persis seperti berikut:
- `foto 1.jpeg`
- `foto3.jpeg`
- `foto 2.jpeg`
- `6z53.jpeg`
- `sanah.jpeg`
- `WhatsApp Image 2026-10-06 at 18.51.30.jpeg`

Foto asli tidak disertakan dalam paket ini karena yang diberikan adalah file HTML saja. Salin foto-foto tersebut dari laptop ke folder ini sebelum mengunggah ke GitHub.

## Upload ke GitHub
1. Buat repository Public bernama `bagankeluarga`.
2. Klik Add file > Upload files.
3. Unggah `index.html`, `style.css`, `script.js`, dan semua foto di atas.
4. Klik Commit changes.
5. Buka Settings > Pages.
6. Pilih Deploy from a branch, branch `main`, folder `/(root)`, lalu Save.
7. Tunggu hingga link Pages muncul.

Pastikan semua nama foto sama persis. File gambar harus berada di lokasi yang sama dengan `index.html`.
